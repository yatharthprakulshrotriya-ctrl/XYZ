import React, { useEffect, useState } from 'react';
import { Box, Paper, Typography, Chip, Grid, TextField, Button } from '@mui/material';
import API from '../../api';

export default function BrowseItems() {
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState('');
  const [filtered, setFiltered] = useState([]);

  useEffect(() => {
    API.get('/items')
      .then(res => {
        setItems(res.data);
        setFiltered(res.data);
      });
  }, []);

  const handleSearch = (e) => {
    setSearch(e.target.value);
    setFiltered(items.filter(
      x => x.name.toLowerCase().includes(e.target.value.toLowerCase()) ||
        x.location.toLowerCase().includes(e.target.value.toLowerCase())
    ));
  };

  return (
    <Box sx={{ mt: 2, px: 1 }}>
      <Typography variant="h4" gutterBottom align="center" sx={{ fontFamily: 'Orbitron' }}>
        Browse Items <span role="img" aria-label="eyes">👀</span>
      </Typography>
      <Box display="flex" justifyContent="center" mb={3}>
        <TextField
          placeholder="Search by name or location"
          value={search}
          onChange={handleSearch}
          sx={{ width: 300, background: "#22272e", borderRadius: 1, mr: 1 }}
          InputProps={{ style: { color: "#0ff" } }}
        />
      </Box>
      <Grid container spacing={3}>
        {filtered.map(item => (
          <Grid item xs={12} md={6} key={item._id}>
            <Paper className="glass" sx={{ p: 3, borderLeft: `6px solid ${item.type === "lost" ? "#f84" : "#0ff"}` }}>
              <Typography variant="h6" color={item.type === "lost" ? "orange" : "cyan"}>
                {item.type === "lost" ? "🚨 LOST" : "🪙 FOUND"}
              </Typography>
              <Typography><b>Name:</b> {item.name}</Typography>
              <Typography><b>Description:</b> {item.description}</Typography>
              <Typography><b>Location:</b> {item.location}</Typography>
              <Typography><b>Date:</b> {item.date ? new Date(item.date).toLocaleDateString() : ""}</Typography>
              <Chip sx={{ mt: 1 }} label={"Posted by: " + (item.postedBy?.username ?? "Unknown")} color="primary" />
              <Typography sx={{ fontSize: "0.93em", mt: 1 }}>
                <b>Contact:</b> <i>{item.contact}</i>
              </Typography>
            </Paper>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}
