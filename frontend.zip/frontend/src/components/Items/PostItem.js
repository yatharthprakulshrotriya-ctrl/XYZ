import React, { useState } from 'react';
import { Box, Paper, Typography, TextField, Button, MenuItem } from '@mui/material';
import API from '../../api';

export default function PostItem() {
  const [form, setForm] = useState({
    type: 'lost', name: '', description: '', location: '', date: '', contact: ''
  });
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async e => {
    e.preventDefault();
    setError('');
    setSuccess('');
    try {
      await API.post('/items', form);
      setSuccess('Item posted successfully!');
      setForm({ type: 'lost', name: '', description: '', location: '', date: '', contact: '' });
    } catch (err) {
      setError(err.response?.data?.error || 'Posting failed');
    }
  };

  return (
    <Box display="flex" justifyContent="center" alignItems="center" minHeight="75vh">
      <Paper className="glass neon-accent" sx={{ p: 5, maxWidth: 420 }}>
        <Typography variant="h4" gutterBottom>Post Lost/Found Item</Typography>
        <form onSubmit={handleSubmit}>
          <TextField
            select label="Type" name="type" value={form.type}
            onChange={handleChange} margin="normal" fullWidth
          >
            <MenuItem value="lost">Lost</MenuItem>
            <MenuItem value="found">Found</MenuItem>
          </TextField>
          <TextField label="Name" name="name" required fullWidth value={form.name} onChange={handleChange} margin="normal" />
          <TextField label="Description" name="description" required fullWidth value={form.description} onChange={handleChange} margin="normal" multiline />
          <TextField label="Location" name="location" required fullWidth value={form.location} onChange={handleChange} margin="normal" />
          <TextField label="Date" name="date" type="date" required fullWidth
            value={form.date} onChange={handleChange} margin="normal" InputLabelProps={{ shrink: true }}
          />
          <TextField label="Contact Information" name="contact" required fullWidth value={form.contact} onChange={handleChange} margin="normal" />
          <Button className="button-neon" type="submit" fullWidth sx={{ mt: 2, mb: 1 }}>Post</Button>
        </form>
        {success && <Typography color="success.main">{success}</Typography>}
        {error && <Typography color="error">{error}</Typography>}
      </Paper>
    </Box>
  );
}
