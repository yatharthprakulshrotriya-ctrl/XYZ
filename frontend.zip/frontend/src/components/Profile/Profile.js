import React, { useEffect, useState } from 'react';
import { Box, Paper, Typography } from '@mui/material';
import API from '../../api';

export default function Profile() {
  const [profile, setProfile] = useState({ username: "", email: "" });

  useEffect(() => {
    const userID = JSON.parse(atob(localStorage.getItem('token').split('.')[1])).id;
    API.get(`/users/${userID}`).then(res => setProfile(res.data));
  }, []);

  return (
    <Box display="flex" justifyContent="center" alignItems="center" minHeight="75vh">
      <Paper className="glass neon-accent" sx={{ p: 5, maxWidth: 420 }}>
        <Typography variant="h4" gutterBottom>My Profile</Typography>
        <Typography><b>Username:</b> {profile.username}</Typography>
        <Typography><b>Email:</b> {profile.email}</Typography>
      </Paper>
    </Box>
  );
}
