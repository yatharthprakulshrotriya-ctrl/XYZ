import React from 'react';
import { Paper, Typography, Box, Button } from '@mui/material';
import { Link } from 'react-router-dom';

export default function Dashboard() {
  return (
    <Box display="flex" flexDirection="column" alignItems="center" mt={6}>
      <Paper className="glass neon-accent" sx={{ p: 6, maxWidth: 600, textAlign: 'center' }}>
        <Typography variant="h3" gutterBottom sx={{ fontFamily: 'Orbitron' }}>
          Welcome to Lost & Found AI<span role="img" aria-label="magnet">🧲</span>
        </Typography>
        <Typography variant="h6" gutterBottom>
          Quickly report and recover missing items — powered by AI smart matching, glassmorphic design, and instant notifications!
        </Typography>
        <Box mt={3}>
          <Button component={Link} to="/browse" className="button-neon" sx={{ mr: 2 }}>Browse Items</Button>
          <Button component={Link} to="/post" className="button-neon">Post Lost/Found</Button>
        </Box>
      </Paper>
    </Box>
  );
}
