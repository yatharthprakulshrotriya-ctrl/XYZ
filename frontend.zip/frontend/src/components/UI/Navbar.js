import React from 'react';
import { AppBar, Toolbar, Typography, Button, Box } from '@mui/material';
import { Link, useNavigate } from 'react-router-dom';

const Navbar = () => {
  const navigate = useNavigate();
  const loggedIn = localStorage.getItem('token');
  const logout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  return (
    <AppBar position="static" sx={{background: 'linear-gradient(90deg,#0f2027,#2b6970 90%)', mb: 3, boxShadow: "0 2px 10px #0ff8"}}>
      <Toolbar>
        <Typography variant="h5" component="div" sx={{ flexGrow: 1, fontWeight: "bold", letterSpacing: 2 }}>
          <Link to="/" style={{ color: "#0ff", textShadow: "0 0 6px #0ff", fontFamily: "Orbitron" }}>Lost & Found <span role="img" aria-label="AI">🤖</span></Link>
        </Typography>
        {loggedIn && <Button color="inherit" component={Link} to="/browse">Browse</Button>}
        {loggedIn && <Button color="inherit" component={Link} to="/post">Post Item</Button>}
        {loggedIn && <Button color="inherit" component={Link} to="/profile">Profile</Button>}
        {loggedIn 
          ? <Button color="inherit" onClick={logout}>Logout</Button>
          : <Button color="inherit" component={Link} to="/login">Login</Button>
        }
      </Toolbar>
    </AppBar>
  );
};

export default Navbar;
