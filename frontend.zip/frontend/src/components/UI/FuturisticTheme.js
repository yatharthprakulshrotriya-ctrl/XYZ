import React from 'react';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';

const theme = createTheme({
  palette: {
    mode: 'dark',
    primary: { main: '#0ff' },
    secondary: { main: '#06dbe7' },
    background: { default: '#181c28', paper: '#23283a' },
  },
  typography: {
    fontFamily: ['Orbitron', 'Roboto', 'sans-serif'].join(','),
    h4: { fontFamily: 'Orbitron' },
    h6: { fontWeight: 700 },
  },
  components: {
    MuiPaper: {
      styleOverrides: {
        root: {
          background: 'rgba(23,25,39,0.7)',
          borderRadius: 16,
          boxShadow: '0 2px 18px 0 #0ff8, 0 1px 3px #021f26',
        }
      }
    }
  }
});

export default function FuturisticTheme({ children }) {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      {children}
    </ThemeProvider>
  );
}
