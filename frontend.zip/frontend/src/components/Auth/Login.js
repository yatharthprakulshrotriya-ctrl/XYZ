import React, { useState } from 'react';
import { Paper, Typography, TextField, Button, Box } from '@mui/material';
import { useNavigate, Link } from 'react-router-dom';
import API from '../../api';

export default function Login() {
  const [form, setForm] = useState({ username: '', password: '' });
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async e => {
    e.preventDefault();
    setError('');
    try {
      const { data } = await API.post('/auth/login', form);
      localStorage.setItem('token', data.token);
      navigate('/');
    } catch (err) {
      setError(err.response?.data?.error || 'Login failed');
    }
  };

  return (
    <Box display="flex" justifyContent="center" alignItems="center" minHeight="75vh">
      <Paper className="glass neon-accent" sx={{ p: 5, maxWidth: 400 }}>
        <Typography variant="h4" gutterBottom>Sign In</Typography>
        <form onSubmit={handleSubmit}>
          <TextField label="Username" name="username" fullWidth required margin="normal" value={form.username} onChange={handleChange} />
          <TextField label="Password" name="password" type="password" fullWidth required margin="normal" value={form.password} onChange={handleChange} />
          <Button className="button-neon" type="submit" fullWidth sx={{ mt: 2, mb: 1 }}>Login</Button>
        </form>
        {error && <Typography color="error">{error}</Typography>}
        <Typography variant="body2" sx={{ mt: 2 }}>
          New user? <Link to="/signup">Sign Up</Link>
        </Typography>
      </Paper>
    </Box>
  );
}
