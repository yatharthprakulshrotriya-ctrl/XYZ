import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/UI/Navbar';
import Login from './components/Auth/Login';
import Signup from './components/Auth/Signup';
import Dashboard from './components/Dashboard/Dashboard';
import BrowseItems from './components/Items/BrowseItems';
import PostItem from './components/Items/PostItem';
import Profile from './components/Profile/Profile';
import FuturisticTheme from './components/UI/FuturisticTheme';

function RequireAuth({ children }) {
  return localStorage.getItem('token') ? children : <Navigate to="/login" />;
}

function App() {
  return (
    <FuturisticTheme>
      <Router>
        <Navbar />
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/" element={<RequireAuth><Dashboard /></RequireAuth>} />
          <Route path="/browse" element={<RequireAuth><BrowseItems /></RequireAuth>} />
          <Route path="/post" element={<RequireAuth><PostItem /></RequireAuth>} />
          <Route path="/profile" element={<RequireAuth><Profile /></RequireAuth>} />
        </Routes>
      </Router>
    </FuturisticTheme>
  );
}

export default App;
