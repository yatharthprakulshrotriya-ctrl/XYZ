// Simple ML-based matcher (can be enhanced with NLP libraries)
const Item = require('../models/Item');

async function recommendMatches(query) {
  // Expected: { name, description, type }
  const type = query.type === 'lost' ? 'found' : 'lost';
  const items = await Item.find({ type });

  // Simple scoring based on text overlap and location
  const scored = items.map(item => {
    let score = 0;
    if (item.name && query.name && item.name.toLowerCase() === query.name.toLowerCase()) score += 2;
    if (item.location && query.location && item.location.toLowerCase() === query.location.toLowerCase()) score += 1;
    if (item.description && query.description && item.description && query.description) {
      const desc1 = item.description.toLowerCase(), desc2 = query.description.toLowerCase();
      if (desc1.includes(desc2) || desc2.includes(desc1)) score += 1;
    }
    return { item, score };
  });
  scored.sort((a, b) => b.score - a.score);
  return scored.filter(x => x.score > 0).map(x => x.item);
}

module.exports = { recommendMatches };
