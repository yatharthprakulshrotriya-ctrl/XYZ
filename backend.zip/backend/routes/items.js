const express = require('express');
const jwt = require('jsonwebtoken');
const Item = require('../models/Item');
const matcher = require('../ml/matcher');
const User = require('../models/User');
const router = express.Router();

function auth(req, res, next) {
  const token = req.header('Authorization')?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'No token provided' });
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch (err) {
    res.status(401).json({ error: 'Invalid token' });
  }
}

// Post lost/found item
router.post('/', auth, async (req, res) => {
  try {
    const item = new Item({ ...req.body, postedBy: req.user.id });
    await item.save();
    res.status(201).json(item);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Get lost/found items
router.get('/', async (req, res) => {
  try {
    const items = await Item.find({}).populate('postedBy', 'username email');
    res.json(items);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get recommended matches using ML/AI matcher
router.post('/recommend', async (req, res) => {
  try {
    const matchItems = await matcher.recommendMatches(req.body);
    res.json(matchItems);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
