# Lost & Found AI - Backend

## How to Run
1. Install dependencies: `npm install`
2. Create a `.env` with your MongoDB URI and JWT secret
3. Start server: `npm start`

## Endpoints
- POST /api/auth/signup
- POST /api/auth/login
- GET /api/items
- POST /api/items (auth required)
- POST /api/items/recommend
- GET /api/users/:id
